pdflatex --jobname=solution-functor_def11 solution.tex
pdflatex --jobname=solution-functor_def12 solution.tex
pdflatex --jobname=solution-functor_def13 solution.tex
pdflatex --jobname=solution-functor_def14 solution.tex
pdflatex --jobname=solution-nonhomogenous_part3 solution.tex
