###################################################
## Start of exercise.R 
###################################################


###################################################
### chunk number 1: aa_SweaveListingsPreparations
###################################################
source('listingPreps.R');


###################################################
### chunk number 2: cobwebplot_func_1 eval=FALSE
###################################################
## cobImapFun <- function(x) {
##   return(2 * x - 0.5 * x ** 2);
## }
## max_iter <- 50;
## y_vector <- x_vector <- numeric(
##   max_iter * 2);
## y_vector[1] <- 0;
## x_vector[1] <- 0.5;
## 
## for(ii in 1:50) {
##   y_vector[2 * ii] <- cobImapFun(
##     x_vector[2 * ii - 1]);
##   y_vector[2 * ii + 1] <-
##     y_vector[2 * ii];
##   x_vector[2 * ii] <- 
##     x_vector[2 * ii - 1];
##   x_vector[2 * ii + 1] <- 
##     y_vector[2 * ii + 1];
## }
## 
## plot( -10:50 / 10, 
##       cobImapFun(-10:50 / 10),
##       xlab='x', 
##       ylab='y', 
##       main='Example cobweb',
##       type='l', 
##       xlim=c(0, 4),
##       ylim=c(0, 2.5), 
##       xaxs='i', 
##       yaxs='i');
## lines(-2:6, -2:6, col='red');
## lines(x_vector, y_vector, 
##       col='blue');


###################################################
### chunk number 3: cobwebplot_func_11
###################################################
cobImapFun <- function(x) {
  return(2 * x - 0.5 * x ** 2);
}
max_iter <- 50;
y_vector <- x_vector <- numeric(max_iter * 2);
y_vector[1] <- 0;
x_vector[1] <- 0.5;

for(ii in 1:50) {
  y_vector[2 * ii] <- cobImapFun(x_vector[2 * ii - 1]);
  y_vector[2 * ii + 1] <- y_vector[2 * ii];
  x_vector[2 * ii] <- x_vector[2 * ii - 1];
  x_vector[2 * ii + 1] <- y_vector[2 * ii + 1];
}

plot(-10:50 / 10, cobImapFun(-10:50 / 10),
     xlab='x', ylab='y', main='Example cobweb',
     type='l', xlim=c(0, 4),
     ylim=c(0, 2.5), xaxs='i', yaxs='i');
lines(-2:6, -2:6, col='red');
lines(x_vector, y_vector, col='blue');


###################################################
###################################################
## Start of guide.R 
###################################################


###################################################
### chunk number 1: aa_SweaveListingsPreparations
###################################################
#require(base)
require(SweaveListingUtils)
require(pgfSweave)
oldRset <- .myRset <- getSweaveListingOption("Rset")
oldRout <- .Rout <- getSweaveListingOption('Rout')
#options(warn=3)
#options(error=recover)
.myRset[['literate']]<-"{<-}{<-}2{<<aa_-}{<<aa_-}2"
.myRset$basicstyle <- "{\\footnotesize\\color{Rcommentcolor}}"
.myRset[['keywordstyle']] <- "{\\footnotesize\\bf\\color{red}}"
.myRset$numbers <- 'left'
.myRset$commentstyle <- "{\\color{black}\\ttfamily\\itshape}"
.myRset$numberstyle="\\tiny"
.Rout$fancyvrb <- 'true'
.Rout$keywordstyle <- "{\\color{Routcolor}}"
.Rout$breaklines <- 'true'
.Rout$linewidth <- "{0.5\\textwidth}"
.myRset$extendedchars <- 'true'
.myRset$breaklines <- 'true'
.myRset$linewidth="{0.5\\textwidth}"
.myRset$otherkeywords <- "{!,!=,~,$,*,\\&,\\%/\\%,\\%*\\%,\\%\\%,<-,<<aa_-,/, \\%in\\%}"
setToBeDefinedPkgs(pkgs = c("base"), keywordstyle="\\bf\\color{red}")
SweaveListingoptions(Rset=.myRset, Rout=.Rout, intermediate = FALSE)
#SweaveListingPreparations()
setCacheDir('cache2')
options(device=quartz);
par(mar=c(2,2,2,2))


###################################################
###################################################
## Start of listingPreps.R 
###################################################


#require(base)
require(SweaveListingUtils)
require(pgfSweave)
oldRset <- .myRset <- getSweaveListingOption("Rset")
options(width=50);
oldRout <- .Rout <- getSweaveListingOption('Rout')
#options(warn=3)
#options(error=recover)
.myRset[['literate']]<-"{<-}{<-}2{<<aa_-}{<<aa_-}2"
.myRset$basicstyle <- "{\\tiny\\color{Rcommentcolor}}"
.myRset[['keywordstyle']] <- "{\\tiny\\bf\\color{red}}"
.myRset$numbers <- 'left'
.myRset$commentstyle <- "{\\color{black}\\ttfamily\\itshape}"
.myRset$numberstyle="\\tiny"
.myRset$escapeinside="{(*@}{@*)}"
.Rout$fancyvrb <- 'true'
.Rout$keywordstyle <- "{\\color{Routcolor}}"
.Rout$breaklines <- 'true'
.Rout$linewidth <- "{0.7\\textwidth}"
.myRset$extendedchars <- 'true'
.myRset$breaklines <- 'true'
.myRset$linewidth="{0.7\\textwidth}"
.myRset$otherkeywords <- "{!,!=,~,$,*,\\&,\\%/\\%,\\%*\\%,\\%\\%,<-,<<aa_-,/, \\%in\\%}"
setToBeDefinedPkgs(pkgs = c("base"), keywordstyle="\\bf\\color{red}")
SweaveListingoptions(Rset=.myRset, Rout=.Rout, intermediate = FALSE)
#SweaveListingPreparations()
setCacheDir('cache2')
#options(device=quartz);
source('maxima_utilities.R')
par(mar=c(2,2,2,2))
###################################################
###################################################
## Start of maxima_utilities.R 
###################################################


#!/usr/bin/env r
# encoding: utf-8
#
# maxima_utils.R
# Copyright (c) 2009 David M. Rosenberg and the University of Chicago.
# All rights reserved.
#
# $Author: root $
# $LastChangedDate: 2009-10-17 16:11:40 -0500 (Sat, 17 Oct 2009) $
# $LastChangedRevision: 128 $
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/
#
# Maintainer: David M. Rosenberg <rosenbergdm@uchicago.edu>
# Created on 2009-10-13
##########################################################################

# maxima_bin="ssh biostat@apalmerlab1.palmerlab.org"
maxima_binary <- maxima_bin <- "/usr/local/bin/rmaxima"

normExpArg <- function (argname, callMatch) {
  mc <- callMatch
  if (class(trySilent(
          expString <- as.character(as.expression(mc[[argname]])))) != 
                                  "try-error" && 
          length(grep(mc[[argname]], pattern = "[\\+|-|\\*|\\/|\\^]")) 
                                          > 0
     ) { }
  else if (class(trySilent(g <- match.fun(mc[[argname]]))) != 
    "try-error") {
    tmpString <- deparse(body(g))
    expString <- tmpString[grep(tmpString, pattern = "\\{|\\}", 
        invert = TRUE)]
    expString <- gsub("^return\\((.*)\\)(;)?$", "\\1", gsub(" ", 
        "", paste(expString, collapse = "")))
  }
  else if (is.character(mc[[argname]])) {
    expString <- mc[[argname]]
  }
  else {
    stop("Error: coercion impossible.")
  }
  return(expString)
}

#' Symbolically calculate derivates.
#'
#' Description here.
#'
#' @param expr the mathematical function to operate on
#'   This argument can be given as a function, an
#'   unevaluated expression, a character string or
#'   raw text.
#' @param var='x' variable to perform differentiation with
#'   respect to.
#' @param degree=1 Order of derivative.
#' @return a function corresponding to the requested
#'   derivative.
#' @export
#' @seealso \code{\link{mInteg}}
#' @seealso \code{\link{mSolve}}
#' @author David Rosenberg \email{rosenbergdm@uchicago.edu}
#' @examples
#' mDeriv(x^3 - 2 * x^2 + 1)
#' f <- function(x) {
#'     return(cos(2 * x) + sin(x)) 
#' }
#' mDeriv(f)
#' mDeriv("(y - 1) * (y + 3)")
mDeriv <- function(expr, var='x', degree=1) {
  mc <- as.list(match.call(expand.dots=TRUE));
  p1 <- normExpArg('expr', mc);

  maxima_cmd <- sprintf('print(diff(%s,%s,%d));', p1, var, degree)
  res <- .performMaximaCall(maxima_cmd);
  f <- function() {};
  chars <- strsplit(res, "")[[1]];
  argnames <- chars[ chars %in% letters ]
  
  args <- vector(mode='list', length=length(argnames));
  names(args) <- argnames;
  formals(f) <- args;
  body(f) <- parse(text=res);
  return(f);
}


#' Symbolically calculate derivates.
#'
#' Description here.
#'
#' @param expr the mathematical function to operate on
#'   This argument can be given as a function, an
#'   unevaluated expression, a character string or
#'   raw text.
#' @param var='x' variable to perform differentiation with
#'   respect to.
#' @param degree=1 Order of derivative.
#' @return a function corresponding to the requested
#'   derivative.
#' @export
#' @seealso \code{\link{mInteg}}
#' @seealso \code{\link{mSolve}}
#' @author David Rosenberg \email{rosenbergdm@uchicago.edu}
#' @examples
#' mDeriv(x^3 - 2 * x^2 + 1)
#' f <- function(x) {
#'     return(cos(2 * x) + sin(x)) 
#' }
#' mDeriv(f)
#' mDeriv("(y - 1) * (y + 3)")
mInt <- function(expr, var='x', degree=1) {
  mc <- as.list(match.call(expand.dots=TRUE));
  p1 <- normExpArg('expr', mc);

  maxima_cmd <- sprintf('print(integrate(%s,%s,%d));', p1, var, degree)
  res <- .performMaximaCall(maxima_cmd);
  f <- function() {};
  chars <- strsplit(res, "")[[1]];
  argnames <- unique(chars[ chars %in% letters ])
  
  args <- vector(mode='list', length=length(argnames));
  names(args) <- argnames;
  formals(f) <- args;
  body(f) <- parse(text=res);
  return(f);
}

mSolve <- function(expr, var='x') {
  p1 <- as.character(expr);
  cmd <- paste('display2d:false; stardisp:true; print(solve(', p1, ',', var,
               '));');
#  cmd2 <- paste("echo 'echo \"", cmd, '" | ', "/usr/bin/maxima'", ' | ',
#                maxima_bin);
  cmd2 <- sprintf("echo '%s' | /usr/local/bin/rmaxima", cmd);
  res <- system(cmd2, intern=TRUE)[9];
  res <- strsplit(gsub('\\]', '', gsub(var, '', gsub('[=|\\[]', '', res))), 
                  ', ')[[1]]
  solutions <- c();
  for (ii in res) {
    solutions <- c(solutions, eval(parse(text=ii)));
  }
  return(solutions);
}


.performMaximaCall <- function(maxima_command, ...) {
  opt_string <- paste(.RMaximaEnv$maxima_opts, collapse=" ");
  maxima_cmd <- paste(opt_string, maxima_command, sep=" ");
  
  if (.RMaximaEnv$is_local) {
    maxima_bin <- .RMaximaEnv$localMaxima;
    sys_cmd <- sprintf("echo '%s' | %s", maxima_cmd, maxima_bin);
    res <- system(sys_cmd, intern=TRUE);
  } else {
    con <- .RMaximaEnv$RServeConnection;
    maxima_bin <- .RMaximaEnv$maxima_bin;
    sys_cmd <- shQuote(sprintf("echo '%s' | %s", maxima_command, maxima_bin));
    cmd_name <- paste(sys_cmd, .RMaximaEnv$mID, sep="_");
    RSassign(con, obj=sys_cmd, name=cmd_name);
    res <- RSeval(quote(eval(sprintf("system(%s, intern=TRUE)", cmd_name))));
  }
  res <- res[1:length(res) > 5];
  res.out <- paste( res[grep("^(\\(%)", res, invert=TRUE,
                   perl=TRUE)], collapse=' ');
  return(res.out);
}



##################################################
## More robust version here                     ##
##################################################

.createRserveEnv <- function() {
  ## sanity check
  require(Rserve)
  require(digest)
  
  rserve_hostname <- 'rosenbergdm.uchicago.edu';
  rserve_port <- 6311;
  rserve_user <- 'biostat';
  rserve_auth <- 'pErdos2';

  .RMaximaEnv <<- new.env(parent=.GlobalEnv, hash=TRUE);
  RServeConnection <- RSconnect(host=rserve_hostname, port=rserve_port);
  RSlogin(RServeConnection, user=rserve_user, pwd=rserve_auth);
    
  maxima_bin <- '/usr/local/bin/maxima'
  localMaxima <- Sys.which(c('maxima', 'maxima'))
  if (all(localMaxima == "")) {
    is_local <- FALSE
  } else {
    is_local <- TRUE;
    localMaxima <- localMaxima[1];
  }
  mid <- substring(digest(c(Sys.time(), sessionInfo)), 1, 16);
  maxima_opts <- c('display2d:false;', 'stardisp:true;')
  
  for (obj in c('maxima_bin', 'localMaxima', 'is_local', 'mid',
                'RServeConnection', 'rserve_auth', 'rserve_user',
                'rserve_port', 'rserve_hostname', 'maxima_opts') ) {
    assign(obj, envir=.RMaximaEnv, value=get(obj));
  }
}

.destroyRserveEnv <- function() {
  ##
  ## TODO: Package teardown.
  ##
}


mSolve.RServe <- function(equ, var='x', ..., symbolic=FALSE) {
  ##  sanity check
  if ( (length(equ) > 1) | symbolic ) {
    stop('Not yet implemented');
  } else if (length(equ) < 1) {
    stop('You must specify the equation(s) to solve.');
  }
  
  ##  values to (eventually) substitute into the result.
  var_values <- list(...);
  
  ##  prep command string
  maxima_commands <- c( 
                        'display2d:false;',
                        'stardisp:true;',
                         paste('print(solve(', equ, ', ', var, '));', sep='')
                      );
                      
  shell_wrap_commands <- paste(   
                                 "echo \"", 
                                 paste(maxima_commands, collapse=' '),
                                 '" | ',
                                 maxima_binary,
                                 sep=' '
                              );
  
  ## Recall hidden persistent connection
  con <- get('RServeConnection', envir=.RMaximaEnv);
  #server_id <- get('server_id', envir=.RMaximaEnv)
  
  RSassign(con, shell_wrap_commands, 'shell_wrap_commands');
  raw_output <- RSeval( con, 
                        quote(system(shell_wrap_commands, intern=TRUE) ) 
                      );
  
  ## High-level deparse of maxima's  output
  
  output_no_message <- raw_output[1:length(raw_output) > 5];
  
  print_lines <- paste( 
              output_no_message[
            grep("^[(\\(%)|(rat)]", output_no_message,
          invert=TRUE, perl=TRUE)],
              collapse=' '
                      );

  deparsed_result <- strsplit(
                            gsub('\\]', '', 
                                gsub(var, '', 
                                  gsub('[=|\\[]', '', print_lines
                                      )
                                    )
                                ),', '
                             )[[1]];
  
  solutions <- numeric(length=length(deparsed_result));
  
  ##
  ## TODO: This is where there ... substitutions need to be made.
  ##
  
  for (ii in seq(along=deparsed_result)) {
    solutions[ii] <- eval( parse(text=deparsed_result[ii]),
                           var_values );
    
  }
  
  return(solutions);
}



.createRserveEnv();
###################################################
###################################################
## Start of pgfsweave-script.R 
###################################################


#!/usr/bin/env Rscript

version <- '$Id: pgfsweave-script.R 44 2009-04-30 07:06:55Z cameronbracken $\n'
usage <- "Usage: pgfsweave-script.R [options] file

A simple front-end for pgfSweave()

Options:
  -h, --help                print short help message and exit
  -v, --version             print pgfSweave version info and exit
  -d, --dvi                 dont use texi2dvi option pdf=T i.e. call latex 
                            (defalt is pdflatex)
  -s, --pgfsweave-only      dont compile to pdf/dvi, only run Sweave
  -n, --graphics-only       dont use the texi2dvi() funciton in R, compile 
                            graphics only ; ignored if --pgfsweave-only is
                            used

Package repositories: 
http://www.rforge.net/pgfSweave/ (for scm)
http://r-forge.r-project.org/projects/pgfsweave/ (for precompiled packages)
"

library(getopt)
library(pgfSweave)

#Column 3: Argument mask of the flag. An integer. Possible values: 
# 0=no argument, 1=required argument, 2=optional argument. 
optspec <- matrix(c(
  'help'          , 'h', 0, "logical",
  'version'       , 'v', 0, "logical",
  'dvi'           , 'd', 0, "logical",
  'pgfsweave-only', 's', 0, "logical",
  'graphics-only' , 'n', 0, "logical"
),ncol=4,byrow=T)

opt <- try(getopt(optspec),silent=TRUE)
if(class(opt) == 'try-error') opt <- list()

if( !is.null(opt$help    )) { cat(usage); q(status=1) }
if( !is.null(opt$version )) { cat(version); q(status=1) }
opt$dvi <- ifelse(is.null(opt$dvi), FALSE, TRUE )
opt[['pgfsweave-only']] <- ifelse(
                            is.null(opt[['pgfsweave-only']]), FALSE, TRUE )
opt[['graphics-only']] <- ifelse(
                            is.null(opt[['graphics-only']]), FALSE, TRUE )
                            
args <- commandArgs(TRUE)
file <- args[length(args)]

cat('pgfsweave-script.R: using options:\n')
print(opt)

if(opt[['graphics-only']]){
    # In the first case run through pgfSweave but no not compile document or 
    # graphics from within R. Instead, run the shell script generated by 
    # pgfSweave() to compile the graphics
    
    pgfSweave(file, pdf=!opt$dvi,compile.tex=FALSE) 
                   
        #compile the graphics
    bn <- strsplit(basename(file), "\\.Rnw")[[1]][1]
    dn <- dirname(file)
    fn <- file.path(dn, bn)
    cmds <- readLines(paste(fn, "sh", sep = "."))
    dummy <- lapply(cmds, system)
    
}else{
    # In this case, just make a call to the R function pgfSweave() with the
    # options intact.
    
    pgfSweave(file, pdf=!opt$dvi,compile.tex = !opt[['pgfsweave-only']])
}


###################################################
###################################################
## Start of week2_lecture.R 
###################################################


###################################################
### chunk number 1: aa_SweaveListingsPreparations
###################################################
source('listingPreps.R');
options(prompt='>', continue=' ', width=40)
#.Rout$escapeinside="{(*@}{@*)}"
#.myRset$escapeinside="{(*@}{@*)}"
#SweaveListingoptions(Rset=.myRset, Rout=.Rout, intermediate = FALSE)
#SweaveListingPreparations()


###################################################
### chunk number 2: v1
###################################################
c('hello', TRUE); c(1, TRUE)
class(c('hello', TRUE)); class(c(1, TRUE));
c('Hello', 14);
class(c(TRUE, TRUE));


###################################################
### chunk number 3: v11
###################################################
my_name <- c('D', 'a', 'v', 'i',
             'd', ' ', 'R', '.');
length(my_name);
names(my_name);
names(my_name) <- 
  c(  paste('first', as.character(1:5),
          sep="_"), 
      'space',
      paste('last', as.character(1:2),
            sep="_") 
   );
my_name;


###################################################
### chunk number 4: v2
###################################################
temp_vec <- 1:5;
temp_vec
temp_vec <- c(temp_vec, 6);
temp_vec;
temp_vec2 <- c(temp_vec, 'Cat');
temp_vec2;
temp_vec[-2];
temp_vec[3] <- 100;
temp_vec;
temp_vec1 <- 1:5; temp_vec2 <- 7:10;
c(temp_vec1, 6, temp_vec2);


###################################################
### chunk number 5: index1
###################################################
my_name[1:3];
my_name[(1:3) * 2];
my_name[c(1, 5, length(my_name))];
my_name['first_3'];
my_name[c('first_1', 'last_1')]


###################################################
### chunk number 6: index2
###################################################
temp_vec <- 1:10;
temp_vec <= 5;
temp_vec[temp_vec <= 5];
my_name == 'D'
my_name[my_name == 'D'];
my_name[my_name == ' ' | my_name == '.'];
my_name[!(my_name %in% c(' ', '.'))];


###################################################
### chunk number 7: lists1
###################################################
list_ex <- list(my_name, 1:5, function(x) { return(1/x) });
list_ex;
list_ex2 <- list(name_ta=my_name, one_to_five=1:5, myfun = function(x) { return(1/x) });


###################################################
### chunk number 8: lists2
###################################################
list_ex2;
class(list_ex);
class(list_ex2[[1]]);


###################################################
### chunk number 9: dfoverview
###################################################
cost_per=c(0.10, 0.25, 0.50);
items=c('spam', 'egg', 'foobar');
on_hand=c(123, 153, 55);
df <- data.frame(items=items, on_hand=on_hand, cost_per=cost_per);
df
total_value <- df$on_hand * df$cost_per


###################################################
### chunk number 10: dfoverview1
###################################################
df <- cbind(df, total_value=total_value)
df
df2 <- cbind(df, weight_per=c(0.5, 0.1, 3))
df2


###################################################
### chunk number 11: dfoverview2
###################################################
df2 <- cbind(
      df2, 
      total_weight=df2$on_hand * df2$weight_per,
      value_density=df2$total_value/(df2$on_hand * df2$weight_per)
            )
df2
class(df2);
is.list(df2);


###################################################
### chunk number 12: complextypessyntax
###################################################
df <- data.frame(items=items, on_hand=on_hand, cost_per=cost_per);
list1 <- as.list(df);
list1;
names(df);
names(df)[1] <- c('My items');
df


###################################################
### chunk number 13: widen
###################################################
op <- options(); options(width=60)


###################################################
### chunk number 14: funcdoc01 eval=FALSE
###################################################
## help(ls);
## ?ls
## ?`+`  # use backquotes when R doesn't
##       #  like the question marks


###################################################
### chunk number 15: funcdoc02
###################################################
# help(package=RInterval); 
# truncated for space
cat(paste(help(package=RInterval)$info[[1]], collapse="\n"), '\n');


###################################################
### chunk number 16: funcdoc03
###################################################
help.search('digest');


###################################################
### chunk number 17: funcdoc04
###################################################
## help.start();


###################################################
### chunk number 18: funcdoc1
###################################################
example(is.integer);


###################################################
### chunk number 19: funcdoc2
###################################################
isTRUE;
lsf.str;


###################################################
### chunk number 20: unwiden
###################################################
options(op);


###################################################
